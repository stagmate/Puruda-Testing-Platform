-- AlterTable
ALTER TABLE "Question" ADD COLUMN "imageUrl" TEXT;
ALTER TABLE "Question" ADD COLUMN "optionAImageUrl" TEXT;
ALTER TABLE "Question" ADD COLUMN "optionBImageUrl" TEXT;
ALTER TABLE "Question" ADD COLUMN "optionCImageUrl" TEXT;
ALTER TABLE "Question" ADD COLUMN "optionDImageUrl" TEXT;
